<?php

namespace App\Http\Middleware;

use Closure;

class AfterMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      \Log::info("AfterMiddleware körs 1!");

        $response = $next($request);

        \Log::info("AfterMiddleware körs 2!");

        return $response;
    }
}
