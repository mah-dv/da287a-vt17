<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Min testsida!</title>
    <link href="<?php echo e(asset("/css/bootstrap.min.css")); ?>" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <h1>Testsida</h1>
      <button class="btn btn-success">En knapp</button>
      <button>En knapp</button>
    </div>

    <script src="<?php echo e(asset("/js/bootstrap.min.js")); ?>"></script>
  </body>
</html>
