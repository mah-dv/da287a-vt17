<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('test', 'TestController@index');

Route::get('demo', function () {
  \Log::info('Demo route körs!');
  return "
    <form action='/demo' method='post'>
      <label>
        Namn:
        <input type='text' name='name'>
      </label>
      <input type='submit' value='skicka'>
    </form>
  ";
});

Route::post('demo', function (Request $request) {
  return "<h1>Hej " . $request->get("name") . "</h1>";
});
/*
Route::group(["middleware" => "auth"], function(){
  Route::get("/movies");
  Route::get("/actors");
  Route::get("");
  Route::get("");
});


Route::get('testar', function(){
  //
})->middleware("BeforeMiddleware");
*/

Route::get("a", function(){
   return "En sida";
});

Route::get("b", function(){
  return Auth::user()->name;
   //return "En sida";
})->middleware("auth");

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
