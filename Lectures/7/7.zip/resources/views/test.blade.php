<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Min testsida!</title>
    <link href="{{ asset("/css/bootstrap.min.css") }}" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <h1>Testsida</h1>
      <button class="btn btn-success">En knapp</button>
      <button>En knapp</button>
    </div>

    <script src="{{ asset("/js/bootstrap.min.js") }}"></script>
  </body>
</html>
